export type Injectable = unknown;
